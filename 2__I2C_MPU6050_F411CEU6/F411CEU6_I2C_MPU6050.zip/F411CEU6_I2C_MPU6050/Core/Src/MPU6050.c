/******************************************************************************
  * @file           : MPU6050.c
  * @Created on     : Sep 25, 2023
  * @brief          : MPU6050_accelerometer and gyroscope sensor reading
  * @Author         : Mani
  *****************************************************************************/
/*include */
#include <main.h>
#include <math.h>

/* external handlers */
extern I2C_HandleTypeDef i2c_handler;

/* variables*/
uint8_t who_i_am;
//for axis
uint8_t axis[5];
int16_t Ax,Ay,Az;
float Axis_x,Axis_y,Axis_z;
//for gyro
uint8_t gyro[5];
int16_t Gx,Gy,Gz;
float Gyro_x,Gyro_y,Gyro_z;
//for temperature
uint8_t temperature[1];
int16_t temper;
float Temperature;



float tilt_x ,tilt_y ,accAngleX ,accAngleY,gyroAngleX,gyroAngleY,roll,pitch,yaw,old_time,present_time,elapsed_time;


/**********************************************************************************
 * Function : MPU6050 initializing
 * Purpose : To initialize axis sensor module
 * *******************************************************************************/
void MPU6050_init(){
	HAL_StatusTypeDef device_status=HAL_I2C_IsDeviceReady(i2c_pointer, Device_ID_Write, 1, 10);//(handler,Device Address, Trials, Timeout in ms)
	if(device_status==HAL_OK){
		printf("**************************************************************************************************\n");
		printf("______I2C slave device is ready______\n");
	}
	else{
		printf("______check your connection to the I2c slave______\n");
	}

	HAL_I2C_Mem_Read(i2c_pointer, Device_ID_Read, WHO_AM_I_REGISTER, 1, &who_i_am, 1, 10);//(handler,Device Address, MemAddress, MemAddSize in bytes, pData, pData Size in bytes, Timeout in ms)

	if(who_i_am==0x68){ //AD0 Contains the 6-bit I2C address of the MPU-60X0. The Power-On-Reset value of Bit6:Bit1 is 110 100.
		printf("______who i_am returns data and device is good______\n");

		HAL_StatusTypeDef power_management=HAL_I2C_Mem_Write(i2c_pointer, Device_ID_Write,PWR_MGMT_1_REGISTER ,1, (uint8_t *)PWR_MGMT_1_REGISTER_Tx_data, 1, 10);//(handler,Device Address, MemAddress, MemAddSize in bytes, pData, pData Size in bytes, Timeout in ms)

		if(power_management==HAL_OK){
			printf("______device is return from sleep mode to wake_up mode______\n");
		}
		else{
			printf("______device is in  sleep______\n");
		}

		HAL_StatusTypeDef GYRO_config=HAL_I2C_Mem_Write(i2c_pointer, Device_ID_Write,GYRO_CONFIG_REGISTER ,1, (uint8_t *)GYRO_CONFIG_REGISTER_Tx_data, 1, 10);//(handler,Device Address, MemAddress, MemAddSize in bytes, pData, pData Size in bytes, Timeout in ms)

				if((GYRO_config==HAL_OK)&&(GYRO_CONFIG_REGISTER_Tx_data==0x00)){
					printf("______Gyro_sensor full scale value set to be ± 250 °/s______\n");
				}
				else if((GYRO_config==HAL_OK)&&(GYRO_CONFIG_REGISTER_Tx_data==0x08)){
									printf("______Gyro_sensor full scale value set to be ± 500 °/s______\n");
				}
				else if((GYRO_config==HAL_OK)&&(GYRO_CONFIG_REGISTER_Tx_data==0x10)){
									printf("______Gyro_sensor full scale value set to be ± 1000 °/s______\n");
				}
				else if((GYRO_config==HAL_OK)&&(GYRO_CONFIG_REGISTER_Tx_data==0x18)){
									printf("______Gyro_sensor full scale value set to be ± 2000 °/s______\n");
				}
				else{
					printf("______Gyro_sensor not working______\n");
				}
		HAL_StatusTypeDef ACCEL_config=HAL_I2C_Mem_Write(i2c_pointer, Device_ID_Write,ACCEL_CONFIG_REGISTER ,1, (uint8_t *)ACCEL_CONFIG_REGISTER_Tx_data, 1, 10);//(handler,Device Address, MemAddress, MemAddSize in bytes, pData, pData Size in bytes, Timeout in ms)

						if((ACCEL_config==HAL_OK)&&(ACCEL_CONFIG_REGISTER_Tx_data==0x00)){
							printf("______Accelero_sensor full scale value set to be ± 2g______\n");
						}
						else if((ACCEL_config==HAL_OK)&&(ACCEL_CONFIG_REGISTER_Tx_data==0x08)){
											printf("______Accelero_sensor full scale value set to be ± 4g______\n");
						}
						else if((ACCEL_config==HAL_OK)&&(ACCEL_CONFIG_REGISTER_Tx_data==0x10)){
											printf("______Accelero_sensor full scale value set to be ± 8g______\n");
						}
						else if((ACCEL_config==HAL_OK)&&(ACCEL_CONFIG_REGISTER_Tx_data==0x18)){
											printf("______Accelero_sensor full scale value set to be ± 16g______\n");
						}
						else{
							printf("______Accelero_sensor not working______\n");
						}
	// Set DATA RATE of 1KHz by writing SMPLRT_DIV register
		HAL_StatusTypeDef sample_rate_div=HAL_I2C_Mem_Write(i2c_pointer, Device_ID_Write, SMPLRT_DIV_REGISTER, 1, (uint8_t *)SMPLRT_DIV_REGISTER_Tx_data, 1, 1000);
						if(sample_rate_div==HAL_OK){
							  printf("______sample rate set to 1khz______\n");
						}
						else{
							  printf("______sample rate not set______\n");
						}

		HAL_StatusTypeDef congifuration=HAL_I2C_Mem_Write(i2c_pointer, Device_ID_Write, CONFIG_REGISTER, 1, (uint8_t *)CONFIG_REGISTER_Tx_data, 1, 1000);
						if(congifuration==HAL_OK){
							printf("______Digital Low Pass Filter set to 5______\n");
						}
						else{
							printf("______Digital Low Pass Filter not set______\n");
					    }

	}

}

/**********************************************************************************
 * Function : MPU6050 Axis sensor reading raw data
 * Purpose  : To read axis sensors Ax,Ay,Az raw data
 * notes    : In this reading i have give first data address and remains are incremented and read by given of 6times
 *            so, for one data as i'm assigned 8bit for 6 data  and combined data as 16bit of 3 data Ax,Ay,Az.
 *            its 16-bit 2’s complement value. so,im using int16 bit to get negative sign.
 * *******************************************************************************/
void Axis_read(){
	HAL_I2C_Mem_Read(&hi2c1, Device_ID_Read, AXIS_DATA_READ_STARTING_REGISTER, 1, axis, 6, 1000);
	Ax=(int16_t)(axis[0]<<8 | axis[1]);
	Ay=(int16_t)(axis[2]<<8 | axis[3]);
	Az=(int16_t)(axis[4]<<8 | axis[5]);
//	printf("raw_accleration data Ax=%d  Ay=%d  Az=%d \n",Ax,Ay,Az);
}

/**********************************************************************************
 * Function : MPU6050 Axis sensor convert Data from Raw Data
 * Purpose  : To convert axis sensors Ax,Ay,Az Raw data to axis data
 * notes    : if full scale range set to ±2g LSB sensitivity is 16384 LSB/g
 * *******************************************************************************/
void Full_scale_2g(){
	Axis_read();
	Axis_x=Ax/16384;
	Axis_y=Ay/16384;
	Axis_z=Az/16384;
//	printf("Acceleration data Axis_x=%.2f g  Axis_y=%.2f g  Axis_z=%.2f g \n",Axis_x,Axis_y,Axis_z);
}

/**********************************************************************************
 * Function : MPU6050 Axis sensor convert Data from Raw Data
 * Purpose  : To convert axis sensors Ax,Ay,Az Raw data to axis data
 * notes    : if full scale range set to ±4g LSB sensitivity is 8192 LSB/g
 * *******************************************************************************/
void Full_scale_4g(){
	Axis_read();
	Axis_x=Ax/8192;
	Axis_y=Ay/8192;
	Axis_z=Az/8192;
//	printf("Acceleration data Axis_x=%.2f g  Axis_y=%.2f g  Axis_z=%.2f g \n",Axis_x,Axis_y,Axis_z);
}

/**********************************************************************************
 * Function : MPU6050 Axis sensor convert Data from Raw Data
 * Purpose  : To convert axis sensors Ax,Ay,Az Raw data to axis data
 * notes    : if full scale range set to ±8g LSB sensitivity is 4096 LSB/g
 * *******************************************************************************/
void Full_scale_8g(){
	Axis_read();
	Axis_x=Ax/4096.0;
	Axis_y=Ay/4096.0;
	Axis_z=Az/4096.0;
//	printf("Acceleration data Axis_x=%.2f g  Axis_y=%.2f g  Axis_z=%.2f g \n",Axis_x,Axis_y,Axis_z);
}

/**********************************************************************************
 * Function : MPU6050 Axis sensor convert Data from Raw Data
 * Purpose  : To convert axis sensors Ax,Ay,Az Raw data to axis data
 * notes    : if full scale range set to ±16g LSB sensitivity is 2048 LSB/g
 * *******************************************************************************/
void Full_scale_16g(){
	Axis_read();
	Axis_x=Ax/2048;
	Axis_y=Ay/2048;
	Axis_z=Az/2048;
//	printf("Acceleration data Axis_x=%.2f g  Axis_y=%.2f g  Axis_z=%.2f g \n",Axis_x,Axis_y,Axis_z);
}

/**********************************************************************************
 * Function : MPU6050 Axis sensor convert Data from Raw Data
 * Purpose  : To convert axis sensors Ax,Ay,Az Raw data to axis data
 * notes    : data calculation and i give divide adding of .0 for get float answer.if did not add this float answer is =0.
 * *******************************************************************************/
void Axis_sensor_data(){
	uint8_t value=ACCEL_CONFIG_REGISTER_Tx_data>>2;
//	printf("val=%d\n",value);
	switch(value){
		case 0:
			Full_scale_2g();
//			printf("______Accelero_sensor value calculated for ± 2g______\n");
			break;
		case 1:
			Full_scale_4g();
//			printf("______Accelero_sensor value calculated for ± 4g______\n");
			break;
		case 2:
			Full_scale_8g();
//			printf("______Accelero_sensor value calculated for ± 8g______\n");
			break;
		case 3:
			Full_scale_16g();
//			printf("______Accelero_sensor value calculated for ± 16g______\n");
			break;
		default:
			break;
	   }
}

/**********************************************************************************
 * Function : MPU6050 Gyro sensor reading raw data
 * Purpose  : To read Gyro sensors Gx,Gy,Gz raw data
 * notes    : In this reading i have give first data address and remains are incremented and read by given of 6times
 *            so, for one data as i'm assigned 8bit for 6 data  and combined data as 16bit of 3 data Gx,Gy,Gz.
 *            its 16-bit 2’s complement value. so,im using int16 bit to get negative sign.
 * *******************************************************************************/
void Gyro_read(){
	HAL_I2C_Mem_Read(&hi2c1, Device_ID_Read, GYRO_DATA_READ_STARTING_REGISTER, 1, gyro, 6, 1000);
	Gx=(int16_t)(gyro[0]<<8 | gyro[1]);
	Gy=(int16_t)(gyro[2]<<8 | gyro[3]);
	Gz=(int16_t)(gyro[4]<<8 | gyro[5]);
//	printf("raw_gyro data Gx=%d  Gy=%d  Gz=%d \n",Gx,Gy,Gz);
}

/**********************************************************************************
 * Function : MPU6050 Gyro sensor convert Data from Raw Data
 * Purpose  : To convert gyro sensors Gx,Gy,Gz Raw data to gyro data
 * notes    : if full scale range set to ±250 °/s LSB sensitivity is 131 LSB/g
 * *******************************************************************************/
void Full_scale_250s(){
	Gyro_read();
	Gyro_x=Gx/131.0;
	Gyro_y=Gy/131.0;
	Gyro_z=Gz/131.0;
//	printf("Gyroscope data Gyro_x=%.2f °/s  Gyro_y=%.2f °/s  Gyro_z=%.2f °/s \n",Gyro_x,Gyro_y,Gyro_z);
}

/**********************************************************************************
 * Function : MPU6050 Gyro sensor convert Data from Raw Data
 * Purpose  : To convert Gyro sensors Gx,Gy,Gz Raw data to Gyro data
 * notes    : if full scale range set to ±500 °/s LSB sensitivity is 65.5 LSB/g
 * *******************************************************************************/
void Full_scale_500s(){
	Gyro_read();
	Gyro_x=Gx/65.5;
	Gyro_y=Gy/65.5;
	Gyro_z=Gz/65.5;
//	printf("Gyroscope data Gyro_x=%.2f °/s  Gyro_y=%.2f °/s  Gyro_z=%.2f °/s \n",Gyro_x,Gyro_y,Gyro_z);
}

/**********************************************************************************
 * Function : MPU6050 Gyro sensor convert Data from Raw Data
 * Purpose  : To convert Gyro sensors Gx,Gy,Gz Raw data to Gyro data
 * notes    : if full scale range set to ±1000 °/s LSB sensitivity is 32.8 LSB/g
 * *******************************************************************************/
void Full_scale_1000s(){
	Gyro_read();
	Gyro_x=Gx/32.8;
	Gyro_y=Gy/32.8;
	Gyro_z=Gz/32.8;
//	printf("Gyroscope data Gyro_x=%.2f °/s  Gyro_y=%.2f °/s  Gyro_z=%.2f °/s \n",Gyro_x,Gyro_y,Gyro_z);
}

/**********************************************************************************
 * Function : MPU6050 Gyro sensor convert Data from Raw Data
 * Purpose  : To convert Gyro sensors Gx,Gy,Gz Raw data to Gyro data
 * notes    : if full scale range set to ±2000 °/s LSB sensitivity is 16.4 LSB/g
 * *******************************************************************************/
void Full_scale_2000s(){
	Gyro_read();
	Gyro_x=Gx/16.4;
	Gyro_y=Gy/16.4;
	Gyro_z=Gz/16.4;
//	printf("Gyroscope data Gyro_x=%.2f °/s  Gyro_y=%.2f °/s  Gyro_z=%.2f °/s \n",Gyro_x,Gyro_y,Gyro_z);
}

/**********************************************************************************
 * Function : MPU6050 Gyro sensor convert Data from Raw Data
 * Purpose  : To convert Gyro sensors Gx,Gy,Gz Raw data to Gyro data
 * notes    : data calculation and i give divide adding of .0 for get float answer.
 *            if did not add this float answer is =0
 * *******************************************************************************/
void Gyro_sensor_data(){
	uint8_t value=GYRO_CONFIG_REGISTER_Tx_data>>2;
//	printf("val=%d\n",value);
	switch(value){
		case 0:
			Full_scale_250s();
//			printf("______gyro_sensor value calculated for ±250 °/s______\n");
			break;
		case 1:
			Full_scale_500s();
//			printf("______gyro_sensor value calculated for ±500 °/s______\n");
			break;
		case 2:
			Full_scale_1000s();
//			printf("______gyro_sensor value calculated for ±1000 °/s______\n");
			break;
		case 3:
			Full_scale_2000s();
//			printf("______gyro_sensor value calculated for ±2000 °/s______\n");
			break;
		default:
			break;
	   }
}

/**********************************************************************************
 * Function : MPU6050 Temperature sensor reading data
 * Purpose  : To read Temperature sensors data
 * notes    : In this reading i have give first data address and remains are incremented and read by given of 2times
 *            so, for one data as i'm assigned 8bit for 2 data  and combined data as 16bit of 1 data temperature.
 *            its 16-bit 2’s complement value. so,im using int16 bit to get negative sign.
 * fotrmula : Temperature in degrees C = (TEMP_OUT Register Value as a signed quantity)/340 + 36.53
 * *******************************************************************************/
void Temperature_read(){
	HAL_I2C_Mem_Read(&hi2c1, Device_ID_Read, TEMPERATURE_READ_STARTING_REGISTER, 1, temperature, 2, 1000);
	temper=(int16_t)(temperature[0]<<8 | temperature[1]);
	Temperature=temper/340 + 36.53;
	printf("Temperature=%.2f °c \n",Temperature);
}

/**********************************************************************************
 * Function : MPU6050 roll,yaw,pitch calculation
 * Purpose  : i got values but yaw is little increment radically in same ,place.i think if it is in movable condition it works well.
 * notes    : im using complimentry filter
 * *******************************************************************************/
void roll_yaw_pitch(){
	  Axis_sensor_data();
	  Gyro_sensor_data();
	  accAngleX   = (atan2(Axis_y, sqrtf(Axis_x *Axis_x + Axis_z * Axis_z)) * 180/M_PI)-0.58;
	  accAngleY   = (atan2((-Axis_x), sqrtf(Axis_y * Axis_y + Axis_z * Axis_z)) * 180/M_PI)+1.58;
//	  accAngleX   = (atan(Axis_y / sqrt(pow(Axis_x, 2) + pow(Axis_z, 2))) * 180 / M_PI) - 0.58; // AccErrorX ~(0.58) See the calculate_IMU_error()custom function for more details
//	  accAngleY   = (atan(-1 * Axis_x / sqrt(pow(Axis_y, 2) + pow(Axis_z, 2))) * 180 / M_PI) + 1.58; // AccErrorY ~(-1.58)
//	printf("mux=%.2f   muy=%.2f  \n",tilt_x,tilt_y);
//	printf("x=%.2f   y=%.2f  \n",accAngleX,accAngleX);
	// === Read gyroscope data === //
	old_time = present_time;        // Previous time is stored before the actual time read
	present_time = HAL_GetTick();          // Current time actual time read
	elapsed_time = (present_time - old_time) / 1000; // Divide by 1000 to get seconds

	// Correct the outputs with the calculated error values
	Gyro_x = Gyro_x + 0.56; // GyroErrorX ~(-0.56)
	Gyro_y = Gyro_y - 2; // GyroErrorY ~(2)
	Gyro_z = Gyro_z + 0.79; // GyroErrorZ ~ (-0.8)
	// Currently the raw values are in degrees per seconds, deg/s, so we need to multiply by sendonds (s) to get the angle in degrees
	gyroAngleX = gyroAngleX + Gyro_x * elapsed_time; // deg/s * s = deg
	gyroAngleY = gyroAngleY + Gyro_y * elapsed_time;
	yaw =  yaw + Gyro_z * elapsed_time;
	// Complementary filter - combine acceleromter and gyro angle values

	gyroAngleX = 0.96 * gyroAngleX + 0.04 * accAngleX;
	gyroAngleY = 0.96 * gyroAngleY + 0.04 * accAngleY;
	roll = gyroAngleX;
	pitch = gyroAngleY;
	printf("roll=%.2f   pitch=%.2f  yaw=%.2f \n",roll,pitch,yaw);

}

