/******************************************************************************
  * @file           : MPU6050.h
  * @Created on     : Sep 25, 2023
  * @brief          : MPU6050_accelerometer and gyroscope sensor reading
  * @Author         : Mani
  *****************************************************************************/

#ifndef INC_MPU6050_H_
#define INC_MPU6050_H_

#define i2c_handler hi2c1
#define i2c_pointer &hi2c1
#define Device_ID_Read    (0b1101000<<1)+1 //0xD0
#define Device_ID_Write   (0b1101000<<1)+0 //0xD1

#define WHO_AM_I_REGISTER     0b01110101       //0x75   who iam register is adc ,its returns 0x68(104) by giving data of WHO_AM_I_REGISTER_Tx_data
#define PWR_MGMT_1_REGISTER   0b01101011 //0x6B power management register
#define GYRO_CONFIG_REGISTER  0b00011011 //0x1B
#define ACCEL_CONFIG_REGISTER 0b00011100 //0x1C
#define SMPLRT_DIV_REGISTER   0b00011001 //0x19  Sample Rate = Gyroscope Output Rate / (1 + SMPLRT_DIV) __default Gyroscope Output Rate = 8kHz
#define CONFIG_REGISTER       0b00011010 //0x1A   Digital Low Pass Filter (DLPF) setting DLPF_CFG[2:0]

#define WHO_AM_I_REGISTER_Tx_data     0b00000000 //0x00
#define PWR_MGMT_1_REGISTER_Tx_data   0b00000000 //0x00 power management register input data
#define GYRO_CONFIG_REGISTER_Tx_data  0b00000000 // full_scale range=0x00 bit 3and4 [0and0] full_scale range [0) -> (00) ->  ± 250 °/s]____ [1) -> (01) -> ± 500 °/s]____ [2) -> (10) -> ± 1000 °/s]____ [3) -> (11) -> ± 2000 °/s]
#define ACCEL_CONFIG_REGISTER_Tx_data 0b00001000 // full_scale range=0x08 bit 3and4 [0and0] full_scale range [0) -> (00) -> ± 2g]____ [1) -> (01) -> ± 4g]____ [2) -> (10) -> ± 8g]____ [3) -> (11) -> ± 16g]
#define SMPLRT_DIV_REGISTER_Tx_data   0b00000111 //0x07  //sample rate 1000hz
#define CONFIG_REGISTER_Tx_data       0b00001001 //0x05  DLPF_CFG 3-bit unsigned value. Configures the DLPF setting. so DLPF_CFG=5

#define AXIS_DATA_READ_STARTING_REGISTER   0b00111011 //0x3B is starting address of axis data reading.  0x3B-0x40 have 8 half data of 4 full data with 2s compliment.so negative sign represent in MSB bit
#define GYRO_DATA_READ_STARTING_REGISTER   0b01000011 //0x43 is starting address of gyro data reading.  0x43-0x48 have 8 half data of 4 full data with 2s compliment.so negative sign represent in MSB bit
#define TEMPERATURE_READ_STARTING_REGISTER 0b01000001 //0x41  is starting address of temperature data reading.  0x41-0x42 have 2 half data of 1 full data with 2s compliment.so negative sign represent in MSB bit

/* Exported functions */
extern void MPU6050_init();
extern void Axis_read();
extern void Axis_sensor_data();
extern void Gyro_read();
extern void Gyro_sensor_data();
extern void temperature_read();
extern void roll_yaw_pitch();

#endif /* INC_MPU6050_H_ */
